import 'package:biznex/biznex.dart';
import 'package:biznex/src/core/model/employee_models/employee_model.dart';

class EmployeeSalaryReports extends StatelessWidget {
  final AppColors theme;
  final Employee employee;

  const EmployeeSalaryReports({
    super.key,
    required this.employee,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [],
    );
  }
}

class ChartSampleData {
  final String x;
  final num y;
  final num secondSeriesYValue;
  final num thirdSeriesYValue;

  ChartSampleData({
    required this.x,
    required this.y,
    required this.secondSeriesYValue,
    required this.thirdSeriesYValue,
  });
}


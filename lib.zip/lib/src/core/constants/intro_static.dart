const introStatic = [
  {
    "uz":
        "Biznex — bu choyxona, kafe, restoran va fast food markazlari uchun yaratilgan zamonaviy POS tizimi. Minimal dizayn, offline ishlash imkoniyati va o‘zbek tilidagi interfeys bilan biznesingizni yangi bosqichga olib chiqing.",
    "ru":
        "Biznex — это современная POS-система для чайхан, кафе, ресторанов и точек быстрого питания. Минималистичный дизайн, офлайн-режим и интерфейс на узбекском языке помогут вывести ваш бизнес на новый уровень."
  },
  {
    "uz":
        "Buyurtmalar chalkashmasin, hisob-kitoblar ortda qolmasin! Biznex bilan siz savdoni tez va oson yuritasiz. Mahalliy til, qulay interfeys va ishonchli qo‘llab-quvvatlash — barchasi siz uchun.",
    "ru":
        "Пусть заказы не путаются, а расчёты всегда под контролем! С Biznex вы управляете продажами быстро и удобно. Локальный язык, простой интерфейс и надёжная поддержка — всё для вашего удобства."
  },
  {
    "uz":
        "Har bir muvaffaqiyatli biznes orqasida kuchli tizim turadi. Biznex — bu sizning biznesingiz uchun sodiq yordamchi: tezkor, sodda, va ishonchli POS yechimi.",
    "ru":
        "За каждым успешным бизнесом стоит надёжная система. Biznex — ваш верный помощник: быстрая, простая и надёжная POS-система для вашего бизнеса."
  }
];

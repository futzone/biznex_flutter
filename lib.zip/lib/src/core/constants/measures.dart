const measures = [
  "kg",
  "gr",
  "litr",
  "tonn",
  "m",
  "mm",
  "mg",
  "dona",
];

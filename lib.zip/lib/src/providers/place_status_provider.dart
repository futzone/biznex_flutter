import 'package:flutter_riverpod/flutter_riverpod.dart';

final placeStatusProvider = StateProvider((ref) => <String, bool>{});
